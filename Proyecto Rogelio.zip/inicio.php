<?php


   session_start();

    $pagina = isset($_GET['op'])? strtolower($_GET['op']) :'principal';
    require_once 'paginas/menu.php';
    require_once 'paginas/'.$pagina.'.php';
    require_once 'paginas/piepagina.php';
 ?>
 