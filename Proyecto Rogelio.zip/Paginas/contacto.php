<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Squash Tolcayuca</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="styles.css" rel="stylesheet" type="text/css" />
<link href="resto.css" rel="stylesheet" type="text/css" />
<meta name="viwport" content="width=device-width, initial-scal=1,maximum-scale=1, height=device-height, user-scale=true/false">
<style >
  h1{
     color: red;
  }
  h2{
     color: white;
  }
  table{

background-color: brown; opacity: 0.9;

  }
  .texto{
   
  font-size: 1.5em;

float: right;
   
  }
</style>
</head>
<body>


  <br>
  <table  align="center" class="tabla" width="100%">
    <tr>
      <td align="left"> <img src="images/sqTol.png" width="100%" ></td>
      <td class="texto"> <h2>Información General</h2><br>
      <img src="images/fish_us2.gif" alt="">       Telefono: 1(234) 567 8910<br><br>
      <img src="images/fish_us1.gif" alt="">       Calle Allende #7, Colonia El Cerrito, Tolcayuca Hidalgo<br><br>
      <img src="images/fish_us3.gif" alt="">       General: SquashTolcayuca@gmail.com
    </td>
    </tr>
  </table>
  <div class="cont_bot"></div>
            
  </body>
</html>
