﻿  <!DOCTYPE html>
  <html>
  <head>
      <title>Menu</title>
  </head>
  <body>
    <header class="clearfix">
    <div class="container">
            <div class="header-left">
                <h1>Squash Tolcayuca</h1>
            </div>
            <div class="header-right">
                <label for="open">
                    <span class="hidden-desktop"></span>
                </label>
                <input type="checkbox" name="" id="open">
                <nav>
                  <a href="?op=index">Home</a>
                  <a href="?op=acerca_de">Acerca de</a>
                  <a href="?op=convocatoria_ext">Convocatorias</a>
                  <a href="?op=Contacto">Contacto</a>
                  <a href="?op=registro">Registro</a>
                  <a href="?op=login">Login</a>
                </nav>
            </div>
        </div>
    </header> 
  </body>
  </html>
 