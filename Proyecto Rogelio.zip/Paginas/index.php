<!DOCTYPE html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Squash Tolcayuca</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="styles.css" rel="stylesheet" type="text/css" />
<link href="styless.css" rel="stylesheet" type="text/css" />
<link href="resto.css" rel="stylesheet" type="text/css" />
<meta name="viwport" content="width=device-width, initial-scal=1,maximum-scale=1, height=device-height, user-scale=true/false">
<style >
  h1{
     color: red;
  }
  h2{
     color: white;
  }
  table{

background-color: brown; opacity: 0.9;

  }
  .texto{
   
  font-size: 1.5em;

float: right;
   
  }
</style>

</head>
<body>


<div class="wrapper">
  <input checked type=radio name="slider" id="slide1" />
  <input type=radio name="slider" id="slide2" />
  <input type=radio name="slider" id="slide3" />
  <input type=radio name="slider" id="slide4" />
  <input type=radio name="slider" id="slide5" />

  <div class="slider-wrapper">
    <div class=inner>
      <article>
        <div class="info top-left">
          <h3>JUEGA CON AMIGOS</h3>
        </div>
       <img src="images/header2.jpg" />
      </article>

      <article>
        <div class="info bottom-right">
          <h3>HAZ EJERCICIO</h3>
        </div>
        <img  src="images/header4.jpg"/>
      </article>

      <article>
        <div class="info bottom-left">
          <h3>DIVIERTETE</h3>
        </div>
        <img src="images/header3.jpg" />
      </article>

      <article>
        <div class="info top-right">
          <h3>ENTRENA</h3>
        </div>
        <img src="images/header5.jpg" />
      </article>

      <article>
        <div class="info bottom-left">
          <h3>ESFUERZATE</h3>
        </div>
        <img src="images/header6.jpg" />
      </article>
    </div>
    <!-- .inner -->
  </div>
  <!-- .slider-wrapper -->

  <div class="slider-prev-next-control">
    <label for=slide1></label>
    <label for=slide2></label>
    <label for=slide3></label>
    <label for=slide4></label>
    <label for=slide5></label>
  </div>
  <!-- .slider-prev-next-control -->

  <div class="slider-dot-control">
    <label for=slide1></label>
    <label for=slide2></label>
    <label for=slide3></label>
    <label for=slide4></label>
    <label for=slide5></label>
  </div>
  <!-- .slider-dot-control -->
</div>

        <!-- content begins -->
        	<table  align="center" class="tabla" width="100%">
    <tr>
      <td align="left"> <img src="images/img8.jpg" width="100%"></td>
      <td class="texto"> <h2>Bienvenido a Squash Tolcayuca</h2><br>
       El squash es un deporte de raqueta que se practica en interiores con dos jugadores y una pelota de goma que puede tener distintos grados de velocidad o rebote. El grado de velocidad y/o rebote se identifica en el color de la pelota.
    </td>
    </tr>
  </table>
  <div class="cont_bot"></div>
            
  </body>
            </body>
</html>
