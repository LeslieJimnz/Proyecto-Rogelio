<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Squash Tolcayuca</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="styles.css" rel="stylesheet" type="text/css" />
<meta name="viwport" content="width=device-width, initial-scal=1,maximum-scale=1, height=device-height, user-scale=true/false">
<style >
  h1{
     color: red;
  }
</style>
</head>
<body>

<!-- header ends -->
        <!-- content begins -->
        		<div class="cont_top"></div>
       			<div id="content">
                	
                	<div style="height:15px"></div>
                    
                  <div id="cont_razd">
                    <div id="right">
                      <h1>APARTAR CANCHA</h1>
                      <div style="height:20px;"></div>
                      <div  class="box_us">
                            <div  class="box_us_l">
                            </div>
                            <div  class="box_us_r">
                               Por favor seleccione el día y la hora en la que desea ocupar la cancha.
                            </div>
                            <div style="clear: both; height:15px;"></div>
                        </div>
                        <div style="height:25px;"></div>
                      	<span class="span_cont">
     
                      </div>

                       <div id="left">
                        <img src="images/calendar.png" width="100%">
                       </div>
               	    
                    <div style="clear: both"></div>
                    </div>
        		</div>
                
      </div>
      <div style="clear: both;"></div>
    </div>
    <div class="cont_bot"></div>

</html>
