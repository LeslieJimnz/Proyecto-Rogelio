<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Squash Tolcayuca</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="styles.css" rel="stylesheet" type="text/css" />
<meta name="viwport" content="width=device-width, initial-scal=1,maximum-scale=1, height=device-height, user-scale=true/false">
<style >
  h1{
     color: red;
  }
</style>

<script type="text/javascript" src="lib/jquery-1.3.2.min.js"></script>
		<script type="text/javascript" src="lib/jquery.tools.js"></script>	
		<script type="text/javascript" src="lib/jquery.custom.js"></script>
		
		<!-- Pirobox setup and styles -->
<script type="text/javascript" src="lib/pirobox.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	$().piroBox({
			my_speed: 400, //animation speed
			bg_alpha: 0.1, //background opacity
			slideShow : false, // true == slideshow on, false == slideshow off
			slideSpeed : 4, //slideshow duration in seconds(3 to 6 Recommended)
			close_all : '.piro_close,.piro_overlay'// add class .piro_overlay(with comma)if you want overlay click close piroBox

	});
});
</script>

<link href="images/style.css" rel="stylesheet" type="text/css" />


<!-- Pirobox setup and styles end-->

</head>
<body>



<!-- header ends -->
        <!-- content begins -->
        		<div class="cont_top"></div>
       			<div id="content">
                <div style="height:10px"></div>
                	<div class="row">
                   	  <div class="box_img2">
                        

                       	<center><h1>Convocatoria 1</h1></center>
                           <a href="images/gallery_big1.jpg"  class="pirobox_gal1" title="1st Project Image"> 
                            <center><img src="images/img31.jpg" width="90%" /></a></center><
                       	<div style="height:15px"></div>                   
                      </div>
                      <div class="box_razd"></div>
                      
                      <div class="box_img2">
                       	<center><h1>Convocatoria 2</h1></center>
                        <a href="images/gallery_big2.jpg" class="pirobox_gal1" title="2nd Project Image">
                          <center><img src="images/img32.jpg" width="90%" /></a></center>
                          	<div style="height:15px"></div>
                             </div>
                      <div class="box_razd"></div>
                      
                      <div class="box_img2">
                       	<center><h1>Convocatoria 3</h1></center>
                        <a href="images/gallery_big3.jpg" class="pirobox_gal1"  title="3rd Project Image">
                          <center><img src="images/img33.jpg" width="100%" /></a></center>
                          	<div style="height:15px"></div>

                   	  </div>
                      
                  	</div>
                	
                	<div style="height:10px"></div>
                     <div style=" height:21px; padding-left: 20px;">
                        
                    </div>
               </div> 
    
      <div style="clear: both;"></div>
    </div>
    <div class="cont_bot"></div>
    
<!-- bottom end --> 
<!-- footer begins -->
            
</html>
