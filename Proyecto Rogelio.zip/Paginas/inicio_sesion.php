<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Squash Tolcayuca</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta name="viwport" content="width=device-width, initial-scal=1,maximum-scale=1, height=device-height, user-scale=true/false">
<link href="styles.css" rel="stylesheet" type="text/css" />
</head>
<body>


<div class="top">

<ul class="round">
			<li><img src="images/header1.jpg" width="500" height="280" /></li>
			<li><img src="images/header2.jpg" width="500" height="280"/></li>
			<li><img src="images/header3.jpg" width="500" height="280" /></li>
			<li><img src="images/header4.jpg" width="500" height="280" /></li>
			<li><img src="images/header5.jpg" width="500" height="280" /></li>
			<li><img src="images/header6.jpg" width="500" height="280" /></li>
</ul>
<script type="text/javascript" src="lib/jquery.js"></script>
<script type="text/javascript" src="lib/jquery.roundabout.js"></script>
<script type="text/javascript">
			
			$(document).ready(function() {
				$('.round').roundabout();
			});
		
		</script>
</div>

        <!-- content begins -->
        		<div class="cont_top"></div>
       			<div id="content">
                    <div class="cont_home">
                    	<div class="home_box">

                        
                            <div style="height:15px"></div>
                        	<img src="images/img11.jpg" alt="" />
                          <div style="height:10px;"></div>
                        	
                          <div style="height:5px"></div>
                        </div><div style="width: 40px; height:20px; float: left;"></div>
                        <div class="home_box">

                        	<h1>Bienvenido a 'Squash Tolcayuca'</h1>
                            <div style="height:15px"></div>
                        	<div style="height:10px;"></div>
                        	El squash es un deporte de raqueta que se practica en interiores con dos jugadores y una pelota de goma que puede tener distintos grados de velocidad o rebote. El grado de velocidad y/o rebote se identifica en el color de la pelota.
                          <div style="height:5px"></div>
 
                      </div><div style="width: 40px; height:20px; float: left;"></div>
                      <div class="home_box">
                            <div style="height:15px"></div>
                        	<img src="images/img13.jpg" alt="" />
                            <div style="height:10px;"></div>
                            <div style="height:5px"></div>
                      </div>
                        
                   	  <div style="clear: both"></div>
                    </div>
        		</div>
                <div class="cont_bot"></div>
</html>
