
<!DOCTYPE html>
<html>
<head>
	<title>Pagina1</title>
</head>
<body>
	<center><h1>Bienvenido a Squash Tolcayuca</h1></center>
</body>
</html>