<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Squash Tolcayuca</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="styles.css" rel="stylesheet" type="text/css" />
<link href="resto.css" rel="stylesheet" type="text/css" />
<meta name="viwport" content="width=device-width, initial-scal=1,maximum-scale=1, height=device-height, user-scale=true/false">
<style >
  h1{
     color: red;
  }
  h2{
     color: white;
  }
  table{
margin-left: 5%;
margin-right: 5%;
background-color: brown; opacity: 0.9;

  }
  .texto{
   
  font-size: 1.5em;

float: right;
   
  }

</style>
</head>
<body>


<!-- header ends -->
        <!-- content begins -->
        	<table  align="center" class="tabla" width="90%">
        		<br>
   <tr>
   	<td></td>
    	 <td class="texto2"><h2>HISTORIA</h2><br></td></tr>
      <tr><td> <img src="images/img22.jpg" width="80%" ><br></td>
     
     <td class="texto"><br><br><br>A principios del siglo XIX esta obsesión con las raquetas y pelotas dio origen a una nueva variedad del deporte en un lugar poco usual: la Prisión Fleet de Londres. ... En 1820 el Raquets, por algún extraño camino, llegó hasta Harrow y otras escuelas inglesas y fue de esta fuente que nació nuestro deporte, el Squash. <br> <br></td>
   
    </tr>

     <tr>

   	<td></td>
    	 <td class="texto2"> <h2><br><br><br>MISIÓN</h2></td></tr>
      <tr><td> <img src="images/squash1.jpg" width="90%" ></td>
     
     <td class="texto"><br><br><br>Preservar los principios básicos del deporte como el respeto, el compromiso, el trabajo en equipo, la cooperación, la participación, la competitividad, el esfuerzo, la amistad y la promoción del juego limpio. <br><br></td>
   
    </tr>
    <tr>
   	<td></td>
    	 <td class="texto2"> <h2><br><br><br>VISIÓN</h2></td></tr>
      <tr><td> <img src="images/squash2.jpg"  width="90%" ></td>
     
     <td class="texto"><br><br><br>Ser referente en nuestro entorno, en la educación deportiva y en la gestión del Squash base. Dotando a los jugadores de recursos y estratégicas adecuadas para su desarrollo deportivo y personal. Estableciendo para ello una educación deportiva orientada al crecimiento del deportista, entendiendo ambos desarrollos complementarios y necesarios por igual entre hombres y mujeres. <br> <br></td>
   
    </tr>
  </table>
                <div class="cont_bot"></div>
            
</html>
